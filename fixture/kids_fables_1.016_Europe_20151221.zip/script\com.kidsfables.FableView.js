$package("com.kidsfables");

/**
 * FableView class.
 * 
 * @author Iulian Rotaru
 * @since 1.0
 * 
 * @constructor Construct an instance of FableView class.
 * @param js.dom.Document ownerDoc element owner document,
 * @param Node node native {@link Node} instance.
 * @assert assertions imposed by {@link js.dom.Element#Element(js.dom.Document, Node)}.
 */
com.kidsfables.FableView = function(ownerDoc, node) {
	this.$super(ownerDoc, node);

	/**
	 * Fable content view. A fable may have many alternative variants, although not usually, besides the base variant.
	 * On fable load first, aka base, variant is displayed, see {@link #_onFableLoaded}.
	 * 
	 * @type js.dom.Element
	 */
	this._contentView = this.getByCssClass("content");

	/**
	 * Variant indices list.
	 * 
	 * @type js.dom.Element
	 */
	this._variantsList = this.getByCssClass("variants");

	/**
	 * Current index on variants list.
	 * 
	 * @type Number
	 */
	this._variantIndex = 0;

	/**
	 * Current loaded fable object.
	 * 
	 * @type Object
	 */
	this._fable = null;

	/**
	 * Play icon.
	 * 
	 * @type js.dom.Element
	 */
	this._playIcon = this.getByCss(".icon.play");

	/**
	 * Headless audio player.
	 * 
	 * @type com.kidsfables.AudioPlayer
	 */
	this._audioPlayer = WinMain.doc.getByTag("audio");
	this._audioPlayer.on("ended", this._onVoiceEnded, this);

	var panorama = WinMain.doc.getByClass(js.widget.Panorama);
	panorama.addClickListener(this._onClick, this);
};

com.kidsfables.FableView.prototype = {
	open : function(fableName) {
		com.kidsfables.DataSource.loadFable(fableName, this._onFableLoaded, this);
	},

	_onFableLoaded : function(fable) {
		this._fable = fable;

		this._loadedVoice = null;
		this._audioPlayer.unloadMedia();
		this._playIcon.addCssClass("play").removeCssClass("pause");

		this.getByTag("img").setSrc(fable.picture);
		this._variantIndex = 0;
		this._loadVariant();

		if (fable.content.length > 1) {
			var variantIndices = [];
			var greeks = "αβγδεζ";
			for (var i = 0; i < fable.content.length; ++i) {
				variantIndices.push({
					index : i.toString(),
					label : greeks.charAt(i)
				});
			}
			this._variantsList.show();
			this._variantsList.setObject(variantIndices);
		}
		else {
			this._variantsList.hide();
		}

		this.removeCssClass("closed");
	},

	_loadVariant : function() {
		this._contentView.setObject(this._fable.content[this._variantIndex]);
		this._playIcon.show(this._fable.content[this._variantIndex].voice);
	},

	_onClick : function(el) {
		if (el.hasCssClass("close")) {
			this._audioPlayer.unloadMedia();
			this._playIcon.removeCssClass("pause").addCssClass("play");
			this.addCssClass("closed");
		}
		else if (el.hasCssClass("play")) {
			this._audioPlayer.loadMedia($format("http://data.kids-fables.com/%s", this._fable.content[this._variantIndex].voice));
			this._audioPlayer.play();
			this._playIcon.removeCssClass("play").addCssClass("pause");
		}
		else if (el.hasCssClass("pause")) {
			this._audioPlayer.pause();
			this._playIcon.removeCssClass("pause").addCssClass("play");
		}
		else if (el.hasCssClass("variant-index")) {
			this._audioPlayer.unloadMedia();
			this._playIcon.removeCssClass("pause").addCssClass("play");
			this._variantIndex = Number(el.getAttr("data-index"));
			this._loadVariant();
		}
	},

	_onVoiceEnded : function(ev) {
		ev.halt();
		this._playIcon.removeCssClass("pause").addCssClass("play");
	},

	/**
	 * Class string representation.
	 * 
	 * @return this class string representation.
	 */
	toString : function() {
		return "com.kidsfables.FableView";
	}
};
$extends(com.kidsfables.FableView, js.dom.Element);
