$package("com.kidsfables");

/**
 * FablesSection class.
 * 
 * @author Iulian Rotaru
 * @since 1.0
 * 
 * @constructor Construct an instance of FablesSection class.
 * @param js.dom.Document ownerDoc element owner document,
 * @param Node node native {@link Node} instance.
 * @assert assertions imposed by {@link js.dom.Element#Element(js.dom.Document, Node)}.
 */
com.kidsfables.FablesSection = function(ownerDoc, node) {
	this.$super(ownerDoc, node);

	/**
	 * Fables section descriptor.
	 * 
	 * @type Object
	 */
	this._section = null;

	this._startIndexView = this.getByCss(".indices .start");
	this._endIndexView = this.getByCss(".indices .end");
	this._fables = this.getByCssClass("fables");

	/**
	 * Fables list view attached to this section.
	 * 
	 * @type com.kidsfables.FablesList
	 */
	this._fablesList = null;

	/**
	 * Fable view attached to this section.
	 * 
	 * @type com.kidsfables.FableView
	 */
	this._fableView = null;

	this._imagesCount = 0;
	this._imagesLoaded = 0;

	var panorama = WinMain.doc.getByClass(js.widget.Panorama);
	panorama.addClickListener(this._onClick, this);
};

com.kidsfables.FablesSection.prototype = {
	_TILE_UNIT : 128,
	_TILE_MARGIN : 2,

	/**
	 * Mark CSS class for fables list menu.
	 * 
	 * @type String
	 */
	_MENU_CSS : "menu",

	/**
	 * Custom attribute for fable tile.
	 * 
	 * @type String
	 */
	_FABLE_ATTR : "data-fable",

	setObject : function(section) {
		this._section = section;
		this._startIndexView.setText($format("%03d", section.startIndex + 1));
		this._endIndexView.setText($format("%03d", section.endIndex));
		this._fables.removeChildren();

		var tileSize = this._TILE_UNIT + this._TILE_MARGIN;

		var left, top, width = 0, height = 0, imagesCount = 0;
		section.fables.forEach(function(fable) {
			fable.img = this._ownerDoc.createElement("img");
			this._fables.addChild(fable.img);
			++imagesCount;

			fable.img.on("load", this._onImageLoaded, this);
			fable.img.setSrc("http://data.kids-fables.com/" + fable.name + "/tile.jpg");
			fable.img.setAttr(this._FABLE_ATTR, fable.name);
			fable.img.setAttr("title", fable.title);
			fable.img.addCssClass("fable");

			left = tileSize * fable.left;
			if (left > width) {
				width = left;
			}
			top = tileSize * fable.top;
			if (top > height) {
				height = top;
			}

			fable.img.style.setLeft(left);
			fable.img.style.setTop(top);
		}, this);

		this._imagesCount = imagesCount;

		width += this._TILE_UNIT;
		height += this._TILE_UNIT;
		this._fables.style.setWidth(width);
		this._fables.style.setHeight(height);
		this.style.setWidth(width);

		this._fableView = this._getFableView();
		this._fablesList = this._getFablesList();
	},

	_onImageLoaded : function(ev) {
		++this._imagesLoaded;
		if (this._imagesCount > this._imagesLoaded) {
			return;
		}

		var tiles = [], i, tileColumnsCount, tileRowsCount, tilesColumnsCount = 0;
		this._section.fables.forEach(function(fable) {
			tileColumnsCount = Math.floor(fable.img.style.getWidth() / this._TILE_UNIT);
			tileRowsCount = Math.floor(fable.img.style.getHeight() / this._TILE_UNIT);

			if (typeof tiles[fable.top] === "undefined") {
				tiles[fable.top] = [];
			}
			for (i = 0; i < tileColumnsCount; ++i) {
				tiles[fable.top][fable.left + i] = true;
				if (tilesColumnsCount < fable.left + i) {
					tilesColumnsCount = fable.left + i;
				}
			}
			for (i = 1; i < tileRowsCount; ++i) {
				if (typeof tiles[fable.top + i] === "undefined") {
					tiles[fable.top + i] = [];
				}
				tiles[fable.top + i][fable.left] = true;
			}
		}, this);

		var tileSize = this._TILE_UNIT + this._TILE_MARGIN;

		for (var top = 0, left; top < tiles.length; ++top) {
			for (left = 0; left <= tilesColumnsCount; ++left) {
				if (tiles[top][left]) {
					continue;
				}
				var icon = this._ownerDoc.createElement("span");
				this._fables.addChild(icon);
				icon.addCssClass("empty");
				icon.addCssClass("fable");
				icon.style.setLeft(tileSize * left);
				icon.style.setTop(tileSize * top);
			}
		}

		this.addCssClass("opened");
	},

	_onClick : function(el) {
		if (el.hasCssClass(this._MENU_CSS)) {
			this._fablesList.toggle();
			return;
		}
		else if (el.hasCssClass("back")) {
			this.toggleCssClass("collapsed");
			return;
		}
		this._fableView.open(el.getAttr(this._FABLE_ATTR));
	},

	_getFablesList : function() {
		var fablesListTemplate = WinMain.doc.getByCss(".components .fables-list");
		var fablesList = fablesListTemplate.clone(true);
		fablesList.setFableView(this._fableView);
		fablesList.setFables(this._section.fables);

		var nextSibling = this.getNextSibling();
		if (nextSibling != null) {
			nextSibling.insertBefore(fablesList);
		}
		else {
			this.getParent().addChild(fablesList);
		}

		return fablesList;
	},

	_getFableView : function() {
		// create fable view element from components template
		var fableViewTemplate = WinMain.doc.getByCss(".components .fable-view");
		fableView = fableViewTemplate.clone(true);

		// get next section or null if current one is the last
		var nextSection = this.getNextSibling();
		while (nextSection != null && !nextSection.hasCssClass("fables-section")) {
			nextSection = nextSection.getNextSibling();
		}

		// insert fable view before next section, if any, or at parent end
		if (nextSection != null) {
			nextSection.insertBefore(fableView);
		}
		else {
			this.getParent().addChild(fableView);
		}

		return fableView;
	},

	/**
	 * Class string representation.
	 * 
	 * @return this class string representation.
	 */
	toString : function() {
		return "com.kidsfables.FablesSection";
	}
};
$extends(com.kidsfables.FablesSection, js.dom.Element);
