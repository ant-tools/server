$package("com.kidsfables");

/**
 * IndexPage class.
 * 
 * @author Iulian Rotaru
 * @since 1.0
 * 
 * @constructor Construct an instance of IndexPage class.
 */
com.kidsfables.IndexPage = function() {
	this.$super();
};

com.kidsfables.IndexPage.prototype = {
	/**
	 * Class string representation.
	 * 
	 * @return this class string representation.
	 */
	toString: function() {
		return "com.kidsfables.IndexPage";
	}
};
$extends(com.kidsfables.IndexPage, com.kidsfables.Page);
