$package("com.kidsfables");

com.kidsfables.AudioPlayer = function(ownerDoc, node) {
	this.$super(ownerDoc, node);
	this._events = this.getCustomEvents();
	this._events.register("media-loaded");

	this._node.addEventListener("canplay", this._onCanPlay.bind(this));
};

com.kidsfables.AudioPlayer.prototype = {
	loadMedia : function(audioTrackURL) {
		this._node.setAttribute("src", audioTrackURL);
	},

	unloadMedia : function() {
		this._node.setAttribute("src", "");
	},

	play : function() {
		this._node.play();
	},

	pause : function() {
		this._node.pause();
	},

	_onCanPlay : function(ev) {
		this._events.fire("media-loaded");
	},

	toString : function() {
		return "com.kidsfables.AudioPlayer";
	}
};
$extends(com.kidsfables.AudioPlayer, js.dom.Element);
$preload(com.kidsfables.AudioPlayer);
