$package("js.samsung");

/**
 * Samsung Smart TV API adapter class.
 * 
 * @author Iulian Rotaru
 * @since 1.0
 * 
 * @constructor Construct an instance of API class.
 * @param js.dom.Document ownerDoc element owner document,
 * @param Node node native {@link Node} instance.
 * @assert assertions imposed by {@link js.dom.Element#Element(js.dom.Document, Node)}.
 */
js.samsung.API = function(ownerDoc, node) {
	this.$super(ownerDoc, node);

	var log = WinMain.doc.getById("message-box");

	if (typeof Common !== "undefined") {
		log.setText("common exists...");

		/**
		 * Samsung API instance.
		 * 
		 * @type Object
		 */
//		this._api = new Common.API.Widget();
//		this._api.sendReadyEvent();

//		this.on("keydown", this._onKeyDown, this);
//		this.focus();

		// alert("samsung api");
	}
};

js.samsung.API.prototype = {
	_onKeyDown : function(ev) {
		// alert(event.keyCode);
		window.location = "play.html";
	},

	/**
	 * Class string representation.
	 * 
	 * @return this class string representation.
	 */
	toString : function() {
		return "js.samsung.API";
	}
};
$extends(js.samsung.API, js.dom.Element);
$preload(js.samsung.API);
