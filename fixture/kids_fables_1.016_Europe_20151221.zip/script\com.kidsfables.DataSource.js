$package("com.kidsfables");

/**
 * DataSource class.
 * 
 * @author Iulian Rotaru
 * @since 1.0
 */
com.kidsfables.DataSource = {
	SERVER_URL : "http://data.kids-fables.com/",

	loadFablesCollection : function(callback, scope) {
		var url = this.SERVER_URL + "fables.json";

		var xhr = new XMLHttpRequest();
		xhr.open('GET', url, true);
		xhr.setRequestHeader("Accept", "application/json");
		xhr.onreadystatechange = handler.bind(this);
		xhr.send();

		function handler(evtXHR) {
			if (xhr.readyState == 4) {
				if (xhr.status == 200) {
					callback.call(scope, JSON.parse(xhr.responseText));
				}
				else {
					alert("Invocation Errors Occured");
				}
			}
		}
	},

	loadFable : function(fableName, callback, scope) {
		var url = this.SERVER_URL + fableName + "/fable_en.json";

		var xhr = new XMLHttpRequest();
		xhr.open('GET', url, true);
		xhr.setRequestHeader("Accept", "application/json");
		xhr.onreadystatechange = handler.bind(this);
		xhr.send();

		function handler(evtXHR) {
			if (xhr.readyState == 4) {
				if (xhr.status == 200) {
					var fable = JSON.parse(xhr.responseText);
					fable.picture = this.SERVER_URL + fable.picture;
					callback.call(scope, fable);
				}
				else {
					alert("Invocation Errors Occured");
				}
			}
		}
	},

	getIconURL : function(fableName) {
		return this.SERVER_URL + fableName + "/icon.jpg";
	},

	/**
	 * Class string representation.
	 * 
	 * @return this class string representation.
	 */
	toString : function() {
		return "com.kidsfables.DataSource";
	}
};
