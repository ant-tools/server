$package("com.kidsfables");

com.kidsfables.Page = function() {
	this.$super();
};

com.kidsfables.Page.prototype = {
	toString : function() {
		return "com.kidsfables.Page";
	}
};
$extends(com.kidsfables.Page, js.ua.Page);
