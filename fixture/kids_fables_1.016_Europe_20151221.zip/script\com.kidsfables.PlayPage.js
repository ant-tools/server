$package("com.kidsfables");

/**
 * PlayPage class.
 * 
 * @author Iulian Rotaru
 * @since 1.0
 * 
 * @constructor Construct an instance of PlayPage class.
 */
com.kidsfables.PlayPage = function() {
	this.$super();
	com.kidsfables.DataSource.loadFablesCollection(function(fablesCollection) {
		var panorama = WinMain.doc.getByClass(js.widget.Panorama);
		panorama.getByCssClass("fables-collection").setObject(fablesCollection);
	}, this);
};

com.kidsfables.PlayPage.prototype = {
	/**
	 * Class string representation.
	 * 
	 * @return this class string representation.
	 */
	toString : function() {
		return "com.kidsfables.PlayPage";
	}
};
$extends(com.kidsfables.PlayPage, com.kidsfables.Page);
