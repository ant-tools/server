$package("com.kidsfables");

/**
 * FablesList class.
 * 
 * @author Iulian Rotaru
 * @since 1.0
 * 
 * @constructor Construct an instance of FablesList class.
 * @param js.dom.Document ownerDoc element owner document,
 * @param Node node native {@link Node} instance.
 * @assert assertions imposed by {@link js.dom.Element#Element(js.dom.Document, Node)}.
 */
com.kidsfables.FablesList = function(ownerDoc, node) {
	this.$super(ownerDoc, node);

	/**
	 * This fables list opened state. It starts on false and is toggled by {@link #open()} method.
	 * 
	 * @type Boolean
	 */
	this._opened = false;

	/**
	 * Associated fable view.
	 * 
	 * @type com.kidsfables.FableView
	 */
	this._fableView = null;

	var panorama = WinMain.doc.getByClass(js.widget.Panorama);
	panorama.addClickListener(this._onClick, this);
};

com.kidsfables.FablesList.prototype = {
	/**
	 * CSS class that mark opened fables list.
	 * 
	 * @type String
	 */
	_CSS_OPENED : "opened",

	/**
	 * CSS class that mark closed fables list.
	 * 
	 * @type String
	 */
	_CSS_CLOSED : "closed",

	toggle : function() {
		this._opened = !this._opened;
		this.addCssClass(this._CSS_OPENED, this._opened);
		this.addCssClass(this._CSS_CLOSED, !this._opened);
	},

	setFableView : function(fableView) {
		this._fableView = fableView;
	},

	setFables : function(fables) {
		fables.forEach(function(fable) {
			fable.icon = com.kidsfables.DataSource.getIconURL(fable.name);
		}, this);
		this.setObject(fables);
	},

	_onClick : function(el) {
		this._fableView.open(el.getParentByCssClass("item").getAttr("data-fable"));
	},

	/**
	 * Class string representation.
	 * 
	 * @return this class string representation.
	 */
	toString : function() {
		return "com.kidsfables.FablesList";
	}
};
$extends(com.kidsfables.FablesList, js.dom.Element);
